/*
  ESP32 DESK PET - MASTER SKETCH v4.2 (touch-adjustable timer, two games)
  ESP32-C3 SuperMini + 128x64 SSD1306 I2C OLED + momentary TTP223.

  All 11 workshop customisations are included. All features start ON.
  Change true to false in FEATURE SWITCHES, then Verify and Upload.
  Edit the numbered LAB settings to personalise your pet.

  PET TOUCH CONTROLS:
    Touch:       immediate reaction (default hearts).
    Double tap:  another expression (default happy); stay on the pet.
    Triple tap:  another expression (default annoyed); stay on the pet.
    Gentle hold: happy petting expression after 0.6 seconds.
    Hold 3 sec:  open the feature menu; release before using the menu.
  MENU: tap to move the highlight; hold 0.9 sec to select.
  Menu: Back to pet / Expressions / Focus timer / Pixel art / Games.
  Focus timer: Open countdown / Change duration / Reset timer / Back.
  Change duration: tap for the next length; hold to set it.
  Games submenu: Jumping game / Reaction test / Back.
  Each game waits for a tap to start. Reaction test: wait for GO!, then tap.
  TIMER/ART/GAME: hold 0.9 sec to return straight to the pet.
  With gestures OFF, touches still react; use USB for extra features.
  Keep GESTURES or USB ON if you want to access the feature menu/screens.

  USB: Serial Monitor, 115200 baud, Newline (or Both NL & CR).
    HELP, STATUS, MENU, NEXT, PET, TIMER, ART, GAME, TAP, HOLD, RESET,
    NORMAL, HAPPY, HEARTS, ANNOYED, MSG Hello!, SET MOOD OFF
  USB feature changes last until reset. Edit the switches for saved defaults.

  Arduino IDE: ESP32C3 Dev Module; USB CDC On Boot = Enabled.
  Libraries: Adafruit SSD1306, Adafruit GFX Library, Adafruit BusIO.
*/

#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <string.h>
#include <stdio.h>

// =====================================================================
// 1. FEATURE SWITCHES - true = ON, false = OFF
// =====================================================================
bool ENABLE_WELCOME = true;        // Lab 1: name and welcome at startup.
bool SHOW_PUPILS = true;           // Lab 2: black pupils in normal eyes.
bool ENABLE_BLINK = true;          // Lab 3: automatic blinking.
bool ENABLE_LOOK = true;           // Lab 3: automatic left/right glances.
bool ENABLE_TOUCH_REACTION = true; // Lab 4: tap shows your chosen reaction.
bool ENABLE_SLEEP = true;          // Lab 5: idle sleeping face (not deep sleep).
bool ENABLE_GESTURES = true;       // Lab 6: expressions + hold-to-open menu.
bool ENABLE_MOOD = true;           // Lab 7: background happiness and mood faces.
bool ENABLE_TIMER = true;          // Lab 8: focus timer screen.
bool ENABLE_ART = true;            // Lab 9: your pixel art screen.
bool ENABLE_GAME = true;           // Lab 10: master switch for the Games menu.
bool ENABLE_JUMP_GAME = true;      // Include Jumping game.
bool ENABLE_REACTION_GAME = true;  // Include Reaction test.
bool ENABLE_USB = true;            // Lab 11: commands from Serial Monitor.
bool ENABLE_HINTS = true;          // Small control hints on the screen.

// =====================================================================
// 2. PERSONALISE YOUR PET - the 11 workshop labs
// =====================================================================

// LAB 1 - NAME AND WELCOME. Plain letters, numbers and punctuation.
const char PET_NAME[] = "Mochi";        // 1 to 10 characters.
const char WELCOME[] = "Hello, human!"; // Up to 21 characters.
const uint32_t WELCOME_MS = 2000;      // 1000 ms = 1 second.

// LAB 2 - EYE SHAPE AND PUPIL POSITION. Screen = 128 x 64 pixels.
const int EYE_W = 26;      // 8 to 32.
const int EYE_H = 26;      // 8 to 30.
const int EYE_GAP = 18;    // 4 to 24.
const int EYE_RADIUS = 8;  // 0 = square; larger = rounder.
const int PUPIL_X = 0;     // Negative = left, positive = right.
const int PUPIL_Y = 0;     // Negative = up, positive = down.

// LAB 3 - PERSONALITY. Shorter intervals = a more lively pet.
const uint32_t BLINK_MS = 3500;
const uint32_t BLINK_CLOSED_MS = 130;
const uint32_t LOOK_MS = 1600;
const int GAZE_RANGE = 4;  // 0 to 6 pixels; 0 = no sideways movement.

// LAB 4 - IMMEDIATE TOUCH REACTION. 0 = smile, 1 = hearts, 2 = annoyed.
const int TOUCH_REACTION = 1;
const uint32_t REACTION_MS = 1500;
const int PETTING_REACTION = 0;       // Smile while gently holding the pad.
const uint32_t PETTING_MS = 600;      // Petting starts after 0.6 seconds.

// LAB 5 - IDLE SLEEP. Only affects the pet screen.
const uint32_t SLEEP_AFTER_MS = 15000;

// LAB 6 - EXPRESSIONS AND DELIBERATE NAVIGATION.
const int DOUBLE_TOUCH_REACTION = 0; // Two quick taps: smile.
const int TRIPLE_TOUCH_REACTION = 2; // Three quick taps: playfully annoyed.
const uint32_t DOUBLE_TAP_MS = 350;  // Gap between short taps in a sequence.
const uint32_t LONG_PRESS_MS = 900;  // Menu select / return from extra screens.
const uint32_t MENU_HOLD_MS = 3000;  // Longer hold opens the menu from the pet.
const uint32_t MENU_TIMEOUT_MS = 20000; // Inactive menu returns to the pet.

// LAB 7 - MOOD. Values are kept between 0 and 100.
const int START_HAPPINESS = 70;
const int PETTING_GAIN = 10;
const int MOOD_LOSS = 1;
const uint32_t MOOD_TICK_MS = 5000;
const int HAPPY_THRESHOLD = 80;
const int SAD_THRESHOLD = 30;

// LAB 8 - FOCUS TIMER. Edit these two settings, then Verify and Upload.
// Examples: 5 min = 5, 0; 25 min = 25, 0; 90 seconds = 1, 30.
const uint32_t FOCUS_MINUTES = 5;        // Whole minutes; default 5 minutes.
const uint32_t FOCUS_EXTRA_SECONDS = 0;  // Extra seconds, from 0 to 59.
// Calculated automatically. No need to edit this line.
const uint32_t FOCUS_SECONDS = FOCUS_MINUTES * 60UL + FOCUS_EXTRA_SECONDS;
// On-device duration choices. Tap cycles upward, then wraps to the shortest.
const uint32_t TIMER_PRESETS_SECONDS[] = {
  1 * 60, 5 * 60, 10 * 60, 15 * 60,
  25 * 60, 30 * 60, 45 * 60, 60 * 60
};

// LAB 9 - PIXEL ART. Each row has 8 pixels: 1 = white, 0 = black.
const char ART_TITLE[] = "MY PIXEL BADGE"; // Up to 21 characters.
const uint8_t PROGMEM BADGE[] = {
  0b00000000,
  0b01100110,
  0b11111111,
  0b11111111,
  0b01111110,
  0b00111100,
  0b00011000,
  0b00000000
};

// LAB 10 - GAME. Speeds use the original workshop's 40 ms frame units.
// The engine compensates for timing variation; no need to edit its loop.
constexpr float JUMP_SPEED = 4.8f;
constexpr float GRAVITY = 0.38f;
constexpr float OBSTACLE_SPEED = 2.0f;

// REACTION GAME - tap to begin; wait for GO!, then touch as fast as possible.
const uint32_t REACTION_WAIT_MIN_MS = 1500;
const uint32_t REACTION_WAIT_MAX_MS = 4500;
const uint32_t REACTION_TIMEOUT_MS = 5000;

// LAB 11 - USB MESSAGES. Try MSG Hello Mochi! in Serial Monitor.
const uint32_t MESSAGE_MS = 3000; // How long a USB message is shown.

// =====================================================================
// 3. HARDWARE - match these to your wires; use 3.3 V for both modules.
// =====================================================================
const int SDA_PIN = 8;
const int SCL_PIN = 9;
const int TOUCH_PIN = 4;
const uint8_t OLED_ADDR = 0x3C; // Run I2C_Check if your OLED uses 0x3D.
const int TOUCH_ACTIVE = HIGH; // Momentary TTP223, HIGH when touched.
const uint32_t DEBOUNCE_MS = 30;
const uint32_t FRAME_MS = 40;
Adafruit_SSD1306 display(128, 64, &Wire, -1);

// =====================================================================
// ENGINE - participants normally do not need to edit below this line.
// =====================================================================
static_assert(sizeof(PET_NAME) > 1 && sizeof(PET_NAME) <= 11,
              "PET_NAME must have 1 to 10 characters");
static_assert(sizeof(WELCOME) <= 22 && sizeof(ART_TITLE) <= 22,
              "Welcome and art title: maximum 21 characters");
static_assert(sizeof(BADGE) == 8, "BADGE needs exactly eight rows");
static_assert(EYE_W >= 8 && EYE_W <= 32, "EYE_W: 8 to 32");
static_assert(EYE_H >= 8 && EYE_H <= 30, "EYE_H: 8 to 30");
static_assert(EYE_GAP >= 4 && EYE_GAP <= 24, "EYE_GAP: 4 to 24");
static_assert(EYE_RADIUS >= 0, "EYE_RADIUS cannot be negative");
static_assert(GAZE_RANGE >= 0 && GAZE_RANGE <= 6, "GAZE_RANGE: 0 to 6");
static_assert(2 * EYE_W + EYE_GAP + 2 * GAZE_RANGE <= 124,
              "Eyes and gaze must fit the screen");
static_assert(BLINK_CLOSED_MS > 0 && BLINK_MS > BLINK_CLOSED_MS,
              "Blink interval must exceed the closed-eye time");
static_assert(LOOK_MS > 0 && SLEEP_AFTER_MS > 0 && REACTION_MS > 0,
              "Look, sleep and reaction times must be positive");
static_assert(WELCOME_MS <= 60000 && MESSAGE_MS > 0 && MESSAGE_MS <= 60000,
              "Welcome/message times: maximum 60000 ms; message > 0");
static_assert(TOUCH_REACTION >= 0 && TOUCH_REACTION <= 2,
              "TOUCH_REACTION: 0 smile, 1 hearts, 2 annoyed");
static_assert(PETTING_REACTION >= 0 && PETTING_REACTION <= 2 &&
              DOUBLE_TOUCH_REACTION >= 0 && DOUBLE_TOUCH_REACTION <= 2 &&
              TRIPLE_TOUCH_REACTION >= 0 && TRIPLE_TOUCH_REACTION <= 2,
              "Petting/double/triple reactions: 0 smile, 1 hearts, 2 annoyed");
static_assert(DOUBLE_TAP_MS > DEBOUNCE_MS &&
              PETTING_MS > DOUBLE_TAP_MS && LONG_PRESS_MS > PETTING_MS &&
              MENU_HOLD_MS > LONG_PRESS_MS && MENU_HOLD_MS <= 10000 &&
              MENU_TIMEOUT_MS > MENU_HOLD_MS,
              "Timing order: double tap < petting < select hold < menu hold");
static_assert(START_HAPPINESS >= 0 && START_HAPPINESS <= 100 &&
              PETTING_GAIN >= 0 && PETTING_GAIN <= 100 &&
              MOOD_LOSS >= 0 && MOOD_LOSS <= 100 && MOOD_TICK_MS > 0,
              "Mood values: 0 to 100; tick time must be positive");
static_assert(SAD_THRESHOLD >= 0 && SAD_THRESHOLD < HAPPY_THRESHOLD &&
              HAPPY_THRESHOLD <= 100, "Check mood thresholds");
static_assert(FOCUS_MINUTES <= 1440 && FOCUS_EXTRA_SECONDS <= 59 &&
              FOCUS_SECONDS > 0 && FOCUS_SECONDS <= 86400,
              "Timer: 1 second to 24 hours; extra seconds must be 0 to 59");
static_assert(GRAVITY > 0 && JUMP_SPEED > 0 && OBSTACLE_SPEED > 0 &&
              OBSTACLE_SPEED <= 8.0f,
              "Game speeds must be positive; obstacle speed max 8");
static_assert(JUMP_SPEED * JUMP_SPEED / (2 * GRAVITY) <= 36.0f,
              "Jump is too high: lower JUMP_SPEED or increase GRAVITY");
static_assert(REACTION_WAIT_MIN_MS >= 500 &&
              REACTION_WAIT_MAX_MS > REACTION_WAIT_MIN_MS &&
              REACTION_WAIT_MAX_MS <= 30000 &&
              REACTION_TIMEOUT_MS >= 1000 && REACTION_TIMEOUT_MS <= 30000,
              "Check reaction-game wait/timeout settings (maximum 30000 ms)");

const int PET_SCREEN = 0, TIMER_SCREEN = 1, ART_SCREEN = 2, GAME_SCREEN = 3;
const int NORMAL_FACE = 0, HAPPY_FACE = 1, HEART_FACE = 2, ANNOYED_FACE = 3;
int mode = PET_SCREEN, chosenFace = NORMAL_FACE, reactionFace = HEART_FACE;
int gazeX = 0, happiness = START_HAPPINESS;
bool welcomeDone = false, reactionOn = false, toastOn = false;
uint32_t bootAt = 0, lastInteractionAt = 0, lastBlinkAt = 0, lastLookAt = 0;
uint32_t lastFrameAt = 0, lastMoodAt = 0, reactionAt = 0, toastAt = 0;
uint32_t toastDuration = 0;
char toastText[22] = "";

bool rawTouch = false, stableTouch = false, longSent = false;
bool hasTapSequence = false, pressActionSent = false;
uint32_t rawChangedAt = 0, pressedAt = 0, lastTapReleasedAt = 0;
int touchCount = 0;
bool menuOpen = false;
const int ROOT_MENU = 0, EXPRESSION_MENU = 1, GAMES_MENU = 2;
const int TIMER_MENU = 3, TIMER_DURATION_MENU = 4;
int menuPage = ROOT_MENU, menuIndex = 0;
uint32_t menuLastActionAt = 0;

bool timerRunning = false, timerDone = false, timerStarted = false;
uint32_t timerDurationSeconds = FOCUS_SECONDS, timerCandidateSeconds = FOCUS_SECONDS;
uint32_t timerRemainingMs = FOCUS_SECONDS * 1000UL, timerUpdatedAt = 0;
float jumpY = 0, velocityY = 0, obstacleX = 128;
bool gameOver = false, gameReady = true;
uint32_t score = 0;
const int JUMP_GAME = 0, REACTION_GAME = 1;
int gameType = JUMP_GAME;
const int REACTION_READY = 0, REACTION_WAIT = 1, REACTION_GO = 2;
const int REACTION_RESULT = 3, REACTION_EARLY = 4, REACTION_MISSED = 5;
int reactionGameState = REACTION_READY;
uint32_t reactionWaitAt = 0, reactionWaitMs = 0, reactionGoAt = 0;
uint32_t reactionResultMs = 0, reactionBestMs = 0;
bool hasReactionBest = false;

char command[64] = "";
size_t commandLength = 0;
bool commandOverflow = false;

bool elapsed(uint32_t now, uint32_t since, uint32_t duration) {
  return uint32_t(now - since) >= duration; // Also works across millis wrap.
}

bool hasGames() {
  return ENABLE_GAME && (ENABLE_JUMP_GAME || ENABLE_REACTION_GAME);
}

bool gameEnabled(int game) {
  return ENABLE_GAME && ((game == JUMP_GAME && ENABLE_JUMP_GAME) ||
                        (game == REACTION_GAME && ENABLE_REACTION_GAME));
}

bool screenEnabled(int screen) {
  if (screen == PET_SCREEN) return true;
  if (screen == TIMER_SCREEN) return ENABLE_TIMER;
  if (screen == ART_SCREEN) return ENABLE_ART;
  if (screen == GAME_SCREEN) return hasGames();
  return false;
}

bool hasExtraScreens() {
  return ENABLE_TIMER || ENABLE_ART || hasGames();
}

void clearGesture() {
  hasTapSequence = false;
  touchCount = 0;
}

void wakePet(uint32_t now) {
  lastInteractionAt = now;
  welcomeDone = true; // A touch or command can dismiss the welcome.
}

void showToast(const char *text, uint32_t now, uint32_t duration) {
  strncpy(toastText, text, sizeof(toastText) - 1);
  toastText[sizeof(toastText) - 1] = '\0';
  toastAt = now;
  toastDuration = duration;
  toastOn = true;
  // A message interrupts the visual cue, so cancel a reaction trial.
  if (mode == GAME_SCREEN && gameType == REACTION_GAME)
    reactionGameState = REACTION_READY;
}

void react(int face, uint32_t now) {
  reactionFace = face;
  reactionAt = now;
  reactionOn = true;
  wakePet(now);
}

void resetTimer(uint32_t now) {
  timerRemainingMs = timerDurationSeconds * 1000UL;
  timerUpdatedAt = now;
  timerRunning = false;
  timerStarted = false;
  timerDone = false;
}

void resetGame() {
  jumpY = 0;
  velocityY = 0;
  obstacleX = 128;
  score = 0;
  gameOver = false;
  gameReady = true;
}

void resetReactionGame() {
  reactionGameState = REACTION_READY;
  reactionWaitAt = reactionWaitMs = reactionGoAt = reactionResultMs = 0;
  // The best score stays available until the board is reset.
}

void reactionGameTap(uint32_t now, bool physicalTouch) {
  if (reactionGameState == REACTION_READY ||
      reactionGameState == REACTION_RESULT ||
      reactionGameState == REACTION_EARLY ||
      reactionGameState == REACTION_MISSED) {
    reactionWaitAt = now;
    reactionWaitMs = uint32_t(random(long(REACTION_WAIT_MIN_MS),
                                    long(REACTION_WAIT_MAX_MS) + 1));
    reactionGameState = REACTION_WAIT;
  } else if (reactionGameState == REACTION_WAIT) {
    reactionGameState = REACTION_EARLY;
  } else if (reactionGameState == REACTION_GO) {
    // Timestamp the start of a validated physical press, excluding debounce.
    uint32_t touchedAt = physicalTouch ? rawChangedAt : now;
    if (int32_t(touchedAt - reactionGoAt) < 0) {
      reactionGameState = REACTION_EARLY;
      return;
    }
    reactionResultMs = uint32_t(touchedAt - reactionGoAt);
    if (reactionResultMs >= REACTION_TIMEOUT_MS) {
      reactionGameState = REACTION_MISSED;
      return;
    }
    if (!hasReactionBest || reactionResultMs < reactionBestMs) {
      reactionBestMs = reactionResultMs;
      hasReactionBest = true;
    }
    reactionGameState = REACTION_RESULT;
  }
}

void updateReactionGame(uint32_t now) {
  if (reactionGameState == REACTION_WAIT && elapsed(now, reactionWaitAt, reactionWaitMs)) {
    reactionGameState = REACTION_GO;
    reactionGoAt = now; // Called immediately before rendering the GO! frame.
  } else if (reactionGameState == REACTION_GO &&
             elapsed(now, reactionGoAt, REACTION_TIMEOUT_MS)) {
    reactionGameState = REACTION_MISSED;
  }
}

void cycleFace(uint32_t now) {
  chosenFace = (chosenFace + 1) % 4;
  reactionOn = false;
  toastOn = false;
  wakePet(now);
}

void selectScreen(int screen, uint32_t now) {
  if (!screenEnabled(screen)) return;
  if (screen == GAME_SCREEN && !gameEnabled(gameType))
    gameType = ENABLE_JUMP_GAME ? JUMP_GAME : REACTION_GAME;
  bool enteringGame = screen == GAME_SCREEN && mode != GAME_SCREEN;
  mode = screen;
  menuOpen = false;
  toastOn = false;
  reactionOn = false;
  clearGesture();
  if (enteringGame) { resetGame(); resetReactionGame(); }
  wakePet(now);
}

void selectGame(int game, uint32_t now) {
  if (!gameEnabled(game)) return;
  gameType = game;
  resetGame();
  resetReactionGame();
  selectScreen(GAME_SCREEN, now);
}

void openTimerDuration(uint32_t now) {
  if (!ENABLE_TIMER) return;
  timerRunning = false; // Pause the old countdown while choosing a new length.
  selectScreen(PET_SCREEN, now);
  menuOpen = true;
  menuPage = TIMER_DURATION_MENU;
  menuIndex = 0;
  timerCandidateSeconds = timerDurationSeconds;
  menuLastActionAt = now;
}

void nextTimerDuration() {
  uint32_t next = 0, shortest = 86401;
  for (uint32_t seconds : TIMER_PRESETS_SECONDS) {
    if (seconds == 0 || seconds > 86400) continue;
    shortest = min(shortest, seconds);
    if (seconds > timerCandidateSeconds && (next == 0 || seconds < next)) next = seconds;
  }
  timerCandidateSeconds = next ? next : (shortest <= 86400 ? shortest : FOCUS_SECONDS);
}

int menuCount() {
  if (menuPage == TIMER_MENU) return 4;
  if (menuPage == TIMER_DURATION_MENU) return 1;
  if (menuPage == EXPRESSION_MENU) return 5;
  if (menuPage == GAMES_MENU)
    return int(ENABLE_JUMP_GAME) + int(ENABLE_REACTION_GAME) + 1;
  return 2 + int(ENABLE_TIMER) + int(ENABLE_ART) + int(hasGames());
}

int rootMenuItem(int index) {
  // Logical items: 0 pet, 1 expressions, 2 timer, 3 art, 4 games.
  int position = 0;
  for (int item = 0; item < 5; ++item) {
    if ((item == 2 && !ENABLE_TIMER) || (item == 3 && !ENABLE_ART) ||
        (item == 4 && !hasGames())) continue;
    if (position++ == index) return item;
  }
  return 0;
}

int gamesMenuItem(int index) {
  int position = 0;
  if (ENABLE_JUMP_GAME && position++ == index) return JUMP_GAME;
  if (ENABLE_REACTION_GAME && position++ == index) return REACTION_GAME;
  return 2; // Back.
}

const char *menuLabel(int index) {
  if (menuPage == TIMER_MENU) {
    const char *labels[] = {"Open countdown", "Change duration", "Reset timer", "Back"};
    return labels[index];
  }
  if (menuPage == TIMER_DURATION_MENU) return "Set duration";
  if (menuPage == EXPRESSION_MENU) {
    const char *labels[] = {"Auto / normal", "Happy", "Hearts", "Annoyed", "Back"};
    return labels[index];
  }
  if (menuPage == GAMES_MENU) {
    int item = gamesMenuItem(index);
    return item == JUMP_GAME ? "Jumping game" :
           (item == REACTION_GAME ? "Reaction test" : "Back");
  }
  const char *labels[] = {"Back to pet", "Expressions", "Focus timer", "Pixel art", "Games"};
  return labels[rootMenuItem(index)];
}

void openMenu(uint32_t now) {
  selectScreen(PET_SCREEN, now);
  menuOpen = true;
  menuPage = ROOT_MENU;
  menuIndex = 0;
  menuLastActionAt = now;
}

void selectMenuItem(uint32_t now) {
  menuLastActionAt = now;
  if (menuPage == TIMER_DURATION_MENU) {
    timerDurationSeconds = timerCandidateSeconds;
    resetTimer(now);
    selectScreen(TIMER_SCREEN, now); // Next tap starts the chosen duration.
  } else if (menuPage == TIMER_MENU) {
    if (menuIndex == 0) selectScreen(TIMER_SCREEN, now);
    else if (menuIndex == 1) openTimerDuration(now);
    else if (menuIndex == 2) { resetTimer(now); selectScreen(TIMER_SCREEN, now); }
    else { menuPage = ROOT_MENU; menuIndex = 2; }
  } else if (menuPage == EXPRESSION_MENU) {
    if (menuIndex == 4) { menuPage = ROOT_MENU; menuIndex = 1; }
    else {
      int face = menuIndex;
      selectScreen(PET_SCREEN, now);
      chosenFace = face;
    }
  } else if (menuPage == GAMES_MENU) {
    int game = gamesMenuItem(menuIndex);
    if (game < 2 && gameEnabled(game)) selectGame(game, now);
    else { menuPage = ROOT_MENU; menuIndex = menuCount() - 1; }
  } else {
    int item = rootMenuItem(menuIndex);
    if (item == 0) selectScreen(PET_SCREEN, now);
    else if (item == 1) { menuPage = EXPRESSION_MENU; menuIndex = 0; }
    else if (item == 2) { menuPage = TIMER_MENU; menuIndex = 0; }
    else if (item == 3) selectScreen(ART_SCREEN, now);
    else { menuPage = GAMES_MENU; menuIndex = 0; }
  }
  clearGesture();
}

void nextMode(uint32_t now) {
  if (!hasExtraScreens()) {
    cycleFace(now);
    return;
  }
  int next = mode;
  do { next = (next + 1) % 4; } while (!screenEnabled(next));
  selectScreen(next, now);
}

void updateTimer(uint32_t now) {
  if (!ENABLE_TIMER || !timerRunning) return;
  uint32_t dt = uint32_t(now - timerUpdatedAt);
  timerUpdatedAt = now;
  if (dt >= timerRemainingMs) {
    timerRemainingMs = 0;
    timerRunning = false;
    timerDone = true;
    selectScreen(TIMER_SCREEN, now); // Bring completion to the front.
    longSent = true; // Do not treat a held finger as a new reset.
  } else {
    timerRemainingMs -= dt;
  }
}

void singleTap(uint32_t now) {
  toastOn = false;
  wakePet(now);
  if (menuOpen) {
    if (menuPage == TIMER_DURATION_MENU) nextTimerDuration();
    else menuIndex = (menuIndex + 1) % menuCount();
    menuLastActionAt = now;
  } else if (mode == PET_SCREEN) {
    if (ENABLE_TOUCH_REACTION) react(TOUCH_REACTION + 1, now);
  } else if (mode == TIMER_SCREEN && ENABLE_TIMER) {
    updateTimer(now);
    if (timerDone) resetTimer(now);
    timerRunning = !timerRunning;
    timerStarted = true;
    timerUpdatedAt = now;
  } else if (mode == GAME_SCREEN && gameEnabled(gameType)) {
    if (gameType == REACTION_GAME) reactionGameTap(now, false);
    else if (gameOver || gameReady) { resetGame(); gameReady = false; }
    else if (jumpY <= 0) velocityY = JUMP_SPEED;
  } else if (mode == ART_SCREEN) {
    showToast(PET_NAME, now, 1800);
  }
}

void longPress(uint32_t now) {
  toastOn = false;
  wakePet(now);
  if (menuOpen) selectMenuItem(now);
  else if (mode == PET_SCREEN) openMenu(now);
  else selectScreen(PET_SCREEN, now);
}

void pollTouch(uint32_t now) {
  bool raw = digitalRead(TOUCH_PIN) == TOUCH_ACTIVE;
  if (raw != rawTouch) {
    rawTouch = raw;
    rawChangedAt = now;
  }
  if (rawTouch != stableTouch && elapsed(now, rawChangedAt, DEBOUNCE_MS)) {
    stableTouch = rawTouch;
    if (stableTouch) {
      pressedAt = now;
      longSent = false;
      pressActionSent = false;
      wakePet(now);
      if (menuOpen) menuLastActionAt = now;
      else if (mode == PET_SCREEN) {
        if (ENABLE_MOOD) happiness = min(100, happiness + PETTING_GAIN);
        if (ENABLE_GESTURES && hasTapSequence &&
            !elapsed(now, lastTapReleasedAt, DOUBLE_TAP_MS))
          touchCount = min(3, touchCount + 1);
        else touchCount = 1;
        toastOn = false;
        if (ENABLE_TOUCH_REACTION) {
          int reaction = touchCount == 1 ? TOUCH_REACTION :
                         (touchCount == 2 ? DOUBLE_TOUCH_REACTION : TRIPLE_TOUCH_REACTION);
          react(reaction + 1, now);
        }
        pressActionSent = true;
      } else if (!ENABLE_GESTURES || (mode == GAME_SCREEN &&
                 ((gameType == JUMP_GAME && !gameReady && !gameOver) ||
                  (gameType == REACTION_GAME &&
                   (reactionGameState == REACTION_WAIT || reactionGameState == REACTION_GO))))) {
        if (mode == GAME_SCREEN && gameType == REACTION_GAME)
          reactionGameTap(now, true);
        else singleTap(now); // Game input remains immediate.
        pressActionSent = true;
      }
    } else {
      lastInteractionAt = now;
      if (menuOpen) menuLastActionAt = now;
      if ((ENABLE_GESTURES || menuOpen) && !longSent) {
        if (!menuOpen && mode == PET_SCREEN) {
          hasTapSequence = !elapsed(now, pressedAt, PETTING_MS);
          lastTapReleasedAt = now;
        } else if (!pressActionSent) {
          singleTap(now); // Menu/timer actions are decided on release.
        }
      }
    }
  }
  if (stableTouch) {
    lastInteractionAt = now; // A held touch keeps the pet awake.
    if (menuOpen) menuLastActionAt = now;
    bool onPet = !menuOpen && mode == PET_SCREEN;
    if (onPet && !longSent && ENABLE_TOUCH_REACTION &&
        elapsed(now, pressedAt, PETTING_MS))
      react(PETTING_REACTION + 1, now); // Keep the petting expression visible.
    uint32_t holdTime = onPet ? MENU_HOLD_MS : LONG_PRESS_MS;
    if (ENABLE_GESTURES && !longSent &&
        elapsed(now, pressedAt, holdTime)) {
      longSent = true;
      clearGesture();
      longPress(now);
    }
  }
  if (!stableTouch && hasTapSequence &&
      elapsed(now, lastTapReleasedAt, DOUBLE_TAP_MS)) clearGesture();
}

bool *findFeature(const char *name) {
  if (!strcmp(name, "WELCOME")) return &ENABLE_WELCOME;
  if (!strcmp(name, "PUPILS")) return &SHOW_PUPILS;
  if (!strcmp(name, "BLINK")) return &ENABLE_BLINK;
  if (!strcmp(name, "LOOK")) return &ENABLE_LOOK;
  if (!strcmp(name, "TOUCH")) return &ENABLE_TOUCH_REACTION;
  if (!strcmp(name, "SLEEP")) return &ENABLE_SLEEP;
  if (!strcmp(name, "GESTURES")) return &ENABLE_GESTURES;
  if (!strcmp(name, "MOOD")) return &ENABLE_MOOD;
  if (!strcmp(name, "TIMER")) return &ENABLE_TIMER;
  if (!strcmp(name, "ART")) return &ENABLE_ART;
  if (!strcmp(name, "GAME")) return &ENABLE_GAME;
  if (!strcmp(name, "JUMP")) return &ENABLE_JUMP_GAME;
  if (!strcmp(name, "REACTION")) return &ENABLE_REACTION_GAME;
  if (!strcmp(name, "USB")) return &ENABLE_USB;
  if (!strcmp(name, "HINTS")) return &ENABLE_HINTS;
  return nullptr;
}

void printFeature(const char *name, bool enabled) {
  Serial.print(name);
  Serial.print("=");
  Serial.println(enabled ? "ON" : "OFF");
}

void printStatus() {
  Serial.println("BUILD=v4.2-touch-timer-no-bar");
  printFeature("WELCOME", ENABLE_WELCOME);
  printFeature("PUPILS", SHOW_PUPILS);
  printFeature("BLINK", ENABLE_BLINK);
  printFeature("LOOK", ENABLE_LOOK);
  printFeature("TOUCH", ENABLE_TOUCH_REACTION);
  printFeature("SLEEP", ENABLE_SLEEP);
  printFeature("GESTURES", ENABLE_GESTURES);
  printFeature("MOOD", ENABLE_MOOD);
  printFeature("TIMER", ENABLE_TIMER);
  printFeature("ART", ENABLE_ART);
  printFeature("GAME", ENABLE_GAME);
  printFeature("JUMP", ENABLE_JUMP_GAME);
  printFeature("REACTION", ENABLE_REACTION_GAME);
  printFeature("USB", ENABLE_USB);
  printFeature("HINTS", ENABLE_HINTS);
  const char *names[] = {"PET", "TIMER", "ART", "GAME"};
  Serial.print("SCREEN=");
  Serial.println(names[mode]);
  Serial.print("TIMER_SECONDS=");
  Serial.println(timerDurationSeconds);
  if (mode == GAME_SCREEN) {
    Serial.print("GAME_TYPE=");
    Serial.println(gameType == JUMP_GAME ? "JUMP" : "REACTION");
  }
  if (menuOpen) Serial.println("MENU=OPEN (TAP moves, HOLD selects)");
  if (hasExtraScreens() && !ENABLE_GESTURES && !ENABLE_USB)
    Serial.println("Extra screens need GESTURES or USB ON for navigation.");
}

void printHelp() {
  Serial.println("HELP STATUS MENU NEXT PET TIMER LENGTH ART GAME JUMP REACTION TAP HOLD RESET");
  Serial.println("NORMAL HAPPY HEARTS ANNOYED | MSG your message");
  Serial.println("SET feature ON/OFF (example: SET MOOD OFF)");
  Serial.println("Features: WELCOME PUPILS BLINK LOOK TOUCH SLEEP");
  Serial.println("GESTURES MOOD TIMER ART GAME JUMP REACTION USB HINTS");
  Serial.println("Changes reset on reboot. SET USB OFF needs RESET to undo.");
}

void setFeature(const char *name, bool enabled, uint32_t now) {
  bool *feature = findFeature(name);
  if (!feature) {
    Serial.println("Unknown feature. Type HELP.");
    return;
  }
  *feature = enabled;
  clearGesture();
  longSent = true; // A settings change cannot finish an old gesture.
  if (!ENABLE_LOOK) gazeX = 0;
  if (!ENABLE_TOUCH_REACTION) reactionOn = false;
  if (!ENABLE_TIMER) resetTimer(now);
  if (!ENABLE_GAME || !ENABLE_JUMP_GAME) resetGame();
  if (!ENABLE_GAME || !ENABLE_REACTION_GAME) resetReactionGame();
  if (!screenEnabled(mode) || (mode == GAME_SCREEN && !gameEnabled(gameType)))
    selectScreen(PET_SCREEN, now);
  if (!ENABLE_GESTURES && menuOpen) selectScreen(PET_SCREEN, now);
  if (menuOpen) {
    if ((menuPage == TIMER_MENU || menuPage == TIMER_DURATION_MENU) && !ENABLE_TIMER) {
      menuPage = ROOT_MENU; menuIndex = 0;
    }
    if (menuPage == GAMES_MENU && !hasGames()) { menuPage = ROOT_MENU; menuIndex = 0; }
    menuIndex = min(menuIndex, menuCount() - 1);
    menuLastActionAt = now;
  }
  lastMoodAt = now;
  lastBlinkAt = now;
  lastLookAt = now;
  wakePet(now);
  printFeature(name, enabled);
  if (!ENABLE_USB) Serial.println("USB commands OFF. Press RESET to restore.");
  if (hasExtraScreens() && !ENABLE_GESTURES && !ENABLE_USB)
    Serial.println("Enable GESTURES or USB in the sketch for extra screens.");
}

void acceptCommand(uint32_t now) {
  // Trim leading/trailing spaces; commands and feature names use capitals.
  char *cmd = command;
  while (*cmd == ' ' || *cmd == '\t') ++cmd;
  size_t length = strlen(cmd);
  while (length && (cmd[length - 1] == ' ' || cmd[length - 1] == '\t'))
    cmd[--length] = '\0';
  if (!length) return;
  if (!strcmp(cmd, "HELP")) { printHelp(); return; }
  if (!strcmp(cmd, "STATUS")) { printStatus(); return; }
  if (!strncmp(cmd, "SET ", 4)) {
    char name[16], value[8], extra[2];
    if (sscanf(cmd + 4, "%15s %7s %1s", name, value, extra) != 2 ||
        (strcmp(value, "ON") && strcmp(value, "OFF"))) {
      Serial.println("Use SET feature ON or SET feature OFF.");
      return;
    }
    setFeature(name, !strcmp(value, "ON"), now);
    return;
  }
  if (!strcmp(cmd, "MENU")) openMenu(now);
  else if (!strcmp(cmd, "LENGTH")) {
    if (!ENABLE_TIMER) { Serial.println("Timer is OFF."); return; }
    openTimerDuration(now);
  }
  else if (!strcmp(cmd, "NEXT")) {
    if (menuOpen) singleTap(now);
    else nextMode(now);
  }
  else if (!strcmp(cmd, "PET")) selectScreen(PET_SCREEN, now);
  else if (!strcmp(cmd, "JUMP") || !strcmp(cmd, "REACTION")) {
    int game = !strcmp(cmd, "JUMP") ? JUMP_GAME : REACTION_GAME;
    if (!gameEnabled(game)) { Serial.println("Game is OFF. Check GAME and its own switch."); return; }
    selectGame(game, now);
  }
  else if (!strcmp(cmd, "TIMER") || !strcmp(cmd, "ART") ||
           !strcmp(cmd, "GAME")) {
    int screen = !strcmp(cmd, "TIMER") ? TIMER_SCREEN :
                 (!strcmp(cmd, "ART") ? ART_SCREEN : GAME_SCREEN);
    if (!screenEnabled(screen)) {
      Serial.println("Screen is OFF. Enable it with SET feature ON.");
      return;
    }
    selectScreen(screen, now);
  } else if (!strcmp(cmd, "TAP")) { clearGesture(); singleTap(now); }
  else if (!strcmp(cmd, "HOLD")) { clearGesture(); longPress(now); }
  else if (!strcmp(cmd, "RESET")) {
    if (mode == TIMER_SCREEN && !menuOpen) resetTimer(now);
    else if (mode == GAME_SCREEN && !menuOpen) {
      if (gameType == REACTION_GAME) resetReactionGame();
      else resetGame();
    }
    else { Serial.println("RESET applies to the timer/game screen."); return; }
  }
  else if (!strcmp(cmd, "NORMAL")) {
    selectScreen(PET_SCREEN, now);
    chosenFace = NORMAL_FACE; // Mood may still choose a mood face.
  } else if (!strcmp(cmd, "HAPPY") || !strcmp(cmd, "HEARTS") ||
             !strcmp(cmd, "ANNOYED")) {
    selectScreen(PET_SCREEN, now);
    react(!strcmp(cmd, "HAPPY") ? HAPPY_FACE :
          (!strcmp(cmd, "HEARTS") ? HEART_FACE : ANNOYED_FACE), now);
  } else if (!strncmp(cmd, "MSG ", 4)) {
    if (strlen(cmd + 4) > 21) {
      Serial.println("Message: maximum 21 characters.");
      return;
    }
    clearGesture();
    showToast(cmd + 4, now, MESSAGE_MS);
  } else {
    Serial.println("Unknown command. Type HELP.");
    return;
  }
  wakePet(now);
  Serial.println("OK");
}

void pollSerial(uint32_t now) {
  // Limit work per loop so a flood of serial bytes cannot freeze animation.
  int budget = 64;
  while (ENABLE_USB && Serial.available() && budget-- > 0) {
    char c = char(Serial.read());
    if (c == '\r') continue;
    if (c == '\n') {
      command[commandLength] = '\0';
      if (commandOverflow) Serial.println("Command too long; ignored.");
      else if (commandLength) acceptCommand(now);
      commandLength = 0;
      commandOverflow = false;
    } else if (static_cast<unsigned char>(c) >= 32 && c <= 126) {
      if (commandLength < sizeof(command) - 1) command[commandLength++] = c;
      else commandOverflow = true;
    } else {
      commandOverflow = true; // Reject unsupported characters as a whole.
    }
  }
}

void centreText(const char *text, int y, int size) {
  display.setTextSize(size);
  int x = (128 - int(strlen(text)) * 6 * size) / 2;
  display.setCursor(max(0, x), y);
  display.print(text);
}

void heart(int x, int y) {
  display.fillCircle(x - 4, y, 5, SSD1306_WHITE);
  display.fillCircle(x + 4, y, 5, SSD1306_WHITE);
  display.fillTriangle(x - 9, y + 1, x + 9, y + 1,
                       x, y + 13, SSD1306_WHITE);
}

void drawPet(uint32_t now) {
  bool asleep = ENABLE_SLEEP && elapsed(now, lastInteractionAt, SLEEP_AFTER_MS);
  int face = reactionOn ? reactionFace : chosenFace;
  if (ENABLE_MOOD && !reactionOn && chosenFace == NORMAL_FACE)
    face = happiness >= HAPPY_THRESHOLD ? HAPPY_FACE :
           (happiness < SAD_THRESHOLD ? ANNOYED_FACE : NORMAL_FACE);
  int x = (128 - 2 * EYE_W - EYE_GAP) / 2 + (ENABLE_LOOK ? gazeX : 0);
  int y = 33 - EYE_H / 2;
  bool closed = asleep || (ENABLE_BLINK && !reactionOn &&
                          !elapsed(now, lastBlinkAt, BLINK_CLOSED_MS));
  for (int i = 0; i < 2; ++i) {
    int ex = x + i * (EYE_W + EYE_GAP), cx = ex + EYE_W / 2;
    if (closed) display.fillRect(ex, 32, EYE_W, 3, SSD1306_WHITE);
    else if (face == HEART_FACE) heart(cx, 27);
    else if (face == HAPPY_FACE) {
      display.drawLine(ex, 35, cx, 27, SSD1306_WHITE);
      display.drawLine(cx, 27, ex + EYE_W, 35, SSD1306_WHITE);
    } else {
      int radius = constrain(EYE_RADIUS, 0, min(EYE_W, EYE_H) / 2);
      display.fillRoundRect(ex, y, EYE_W, EYE_H, radius, SSD1306_WHITE);
      if (SHOW_PUPILS) {
        int px = constrain(cx + PUPIL_X, ex + 3, ex + EYE_W - 4);
        int py = constrain(33 + PUPIL_Y, y + 3, y + EYE_H - 4);
        display.fillCircle(px, py, 2, SSD1306_BLACK);
      }
      if (face == ANNOYED_FACE) {
        int high = i == 0 ? y : y + 8, low = i == 0 ? y + 8 : y;
        display.fillTriangle(ex, y, ex + EYE_W, y,
          i == 0 ? ex + EYE_W : ex, y + 9, SSD1306_BLACK);
        display.drawLine(ex, high - 2, ex + EYE_W, low - 2, SSD1306_WHITE);
      }
    }
  }
  if (asleep) centreText("Zzz", 54, 1);
}

void drawMenu() {
  if (menuPage == TIMER_DURATION_MENU) {
    centreText("TIMER DURATION", 2, 1);
    char duration[12];
    snprintf(duration, sizeof(duration), "%02lu:%02lu",
      (unsigned long)(timerCandidateSeconds / 60), (unsigned long)(timerCandidateSeconds % 60));
    centreText(duration, 21, 2);
    centreText("Choose your duration", 42, 1);
    centreText("Tap next Hold set", 56, 1);
    return;
  }
  centreText(menuPage == ROOT_MENU ? "FEATURE MENU" :
             (menuPage == EXPRESSION_MENU ? "EXPRESSIONS" :
              (menuPage == TIMER_MENU ? "FOCUS TIMER" : "GAMES")), 0, 1);
  display.setTextSize(1);
  for (int i = 0; i < menuCount(); ++i) {
    display.setCursor(0, 12 + i * 8);
    display.print(i == menuIndex ? "> " : "  ");
    display.print(menuLabel(i));
  }
  // Menu instructions are always shown: essential controls, not decoration.
  centreText("Tap next Hold select", 56, 1);
}

void drawTimer() {
  centreText("FOCUS TIMER", 2, 1);
  uint32_t seconds = (timerRemainingMs + 999UL) / 1000UL;
  char clockText[12];
  snprintf(clockText, sizeof(clockText), "%02lu:%02lu",
           (unsigned long)(seconds / 60), (unsigned long)(seconds % 60));
  // Long timers (e.g. 24 hours) use size 2 only if they fit.
  centreText(clockText, 20, strlen(clockText) <= 10 ? 2 : 1);
  centreText(timerDone ? "Done! Take a break" :
             (timerRunning ? "Running" : (timerStarted ? "Paused" : "Ready")),
             40, 1);
  if (ENABLE_HINTS) centreText(ENABLE_GESTURES ? "Tap run Hold back" : "Tap: start/pause", 54, 1);
}

void drawArt() {
  centreText(ART_TITLE, 2, 1);
  for (int row = 0; row < 8; ++row) {
    uint8_t bits = pgm_read_byte(&BADGE[row]);
    for (int col = 0; col < 8; ++col)
      if (bits & (0x80 >> col))
        display.fillRect(48 + col * 4, 16 + row * 4, 4, 4, SSD1306_WHITE);
  }
  centreText(PET_NAME, 54, 1);
}

void updateGame(uint32_t dtMs) {
  if (gameOver || gameReady) return;
  // Small substeps prevent the obstacle skipping a collision on a slow frame.
  // Cap one update at 200 ms; a stalled display does not cause a huge jump.
  uint32_t remaining = min(dtMs, uint32_t(200));
  while (remaining && !gameOver) {
    uint32_t stepMs = min(remaining, uint32_t(10));
    float step = float(stepMs) / float(FRAME_MS);
    jumpY += velocityY * step - 0.5f * GRAVITY * step * step;
    velocityY -= GRAVITY * step;
    if (jumpY <= 0) { jumpY = 0; velocityY = 0; }
    obstacleX -= OBSTACLE_SPEED * step;
    if (obstacleX < -8) {
      obstacleX = 128 + random(0, 35);
      ++score;
    }
    // Player x=20..30, bottom=54-jumpY. Obstacle top=42, width=8.
    if (obstacleX < 30 && obstacleX + 8 > 20 && jumpY < 12)
      gameOver = true;
    remaining -= stepMs;
  }
}

void drawGame() {
  if (gameType == REACTION_GAME) {
    centreText("REACTION TEST", 2, 1);
    if (reactionGameState == REACTION_READY) {
      centreText("Tap to begin", 27, 1);
      if (ENABLE_GESTURES) centreText("Hold: back to pet", 54, 1);
    } else if (reactionGameState == REACTION_WAIT) {
      centreText("WAIT...", 23, 2);
      centreText("Don't tap yet", 54, 1);
    } else if (reactionGameState == REACTION_GO) {
      centreText("GO!", 20, 3);
      centreText("Tap now!", 54, 1);
    } else if (reactionGameState == REACTION_RESULT) {
      char result[22];
      snprintf(result, sizeof(result), "%lu ms", (unsigned long)reactionResultMs);
      centreText(result, 20, 2);
      snprintf(result, sizeof(result), "Best %lu ms", (unsigned long)reactionBestMs);
      centreText(result, 43, 1);
      centreText("Tap: play again", 56, 1);
    } else {
      centreText(reactionGameState == REACTION_EARLY ? "Too soon!" : "Missed it!", 22, 2);
      centreText("Tap: try again", 56, 1);
    }
    return;
  }
  if (gameReady) {
    centreText("JUMPING GAME", 5, 1);
    centreText("Tap to start", 27, 1);
    if (ENABLE_GESTURES) centreText("Hold: back to pet", 54, 1);
    return;
  }
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print("JUMP ");
  display.print(score);
  display.drawLine(0, 54, 127, 54, SSD1306_WHITE);
  display.fillRect(20, 44 - int(jumpY), 10, 10, SSD1306_WHITE);
  display.fillRect(int(obstacleX), 42, 8, 12, SSD1306_WHITE);
  if (ENABLE_HINTS)
    centreText(ENABLE_GESTURES ? "Tap jump Hold back" : "Tap: jump", 56, 1);
  if (gameOver) {
    display.fillRect(0, 17, 128, 24, SSD1306_BLACK);
    centreText("GAME OVER", 18, 1);
    centreText("Tap to restart", 31, 1);
  }
}

void setup() {
  Serial.begin(115200); // Diagnostics still work with USB commands OFF.
  pinMode(TOUCH_PIN, INPUT);
  delay(700); // Do not touch the TTP223 during its power-up calibration.
  randomSeed(micros());
  if (!Wire.begin(SDA_PIN, SCL_PIN)) {
    Serial.println("I2C could not start. Check the hardware pin settings.");
    while (true) delay(100);
  }
  Wire.beginTransmission(OLED_ADDR);
  if (Wire.endTransmission() != 0) {
    Serial.println("No OLED response: check wires/address or use I2C_Check.");
    while (true) delay(100);
  }
  // periphBegin=false preserves our explicit SDA/SCL pin selection.
  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR, true, false)) {
    Serial.println("OLED buffer allocation failed.");
    while (true) delay(100);
  }
  display.setTextColor(SSD1306_WHITE);
  display.setTextWrap(false);
  display.clearDisplay();
  display.display();
  bootAt = lastInteractionAt = lastLookAt = lastMoodAt = lastFrameAt = millis();
  lastBlinkAt = bootAt - BLINK_CLOSED_MS; // Start with open eyes.
  welcomeDone = !ENABLE_WELCOME || WELCOME_MS == 0;
  resetTimer(bootAt);
  resetGame();
  resetReactionGame();
  rawTouch = stableTouch = digitalRead(TOUCH_PIN) == TOUCH_ACTIVE;
  rawChangedAt = pressedAt = bootAt;
  longSent = stableTouch; // Ignore a finger already held during startup.
  Serial.println("Desk pet NO-BAR build ready. Type STATUS to check version.");
  printStatus();
}

void loop() {
  uint32_t now = millis();
  updateTimer(now); // Timer runs in the background on any screen.
  pollTouch(now);
  if (ENABLE_USB) pollSerial(now);
  if (menuOpen && !stableTouch && elapsed(now, menuLastActionAt, MENU_TIMEOUT_MS))
    selectScreen(PET_SCREEN, now);
  if (reactionOn && elapsed(now, reactionAt, REACTION_MS)) reactionOn = false;
  if (toastOn && elapsed(now, toastAt, toastDuration)) toastOn = false;
  if (!ENABLE_WELCOME || elapsed(now, bootAt, WELCOME_MS)) welcomeDone = true;
  if (ENABLE_BLINK && elapsed(now, lastBlinkAt, BLINK_MS)) lastBlinkAt = now;
  if (ENABLE_LOOK && elapsed(now, lastLookAt, LOOK_MS)) {
    lastLookAt = now;
    gazeX = random(-GAZE_RANGE, GAZE_RANGE + 1);
  }
  if (ENABLE_MOOD && elapsed(now, lastMoodAt, MOOD_TICK_MS)) {
    uint32_t ticks = uint32_t(now - lastMoodAt) / MOOD_TICK_MS;
    lastMoodAt += ticks * MOOD_TICK_MS;
    // Mood is saturated at zero; cap missed ticks before multiplication.
    int loss = int(min(ticks, uint32_t(100))) * MOOD_LOSS;
    happiness = max(0, happiness - loss);
  }
  if (!screenEnabled(mode) || (mode == GAME_SCREEN && !gameEnabled(gameType)))
    selectScreen(PET_SCREEN, now);
  if (!elapsed(now, lastFrameAt, FRAME_MS)) return;
  uint32_t dtMs = uint32_t(now - lastFrameAt);
  lastFrameAt = now;
  // Game pauses on other screens, during startup, and while showing messages.
  if (mode == GAME_SCREEN && hasGames() && welcomeDone && !toastOn && !menuOpen) {
    if (gameType == REACTION_GAME) updateReactionGame(now);
    else updateGame(dtMs);
  }
  display.clearDisplay();
  if (!welcomeDone) {
    centreText(PET_NAME, 15, 2);
    centreText(WELCOME, 43, 1);
  } else if (toastOn) centreText(toastText, 27, 1);
  else if (menuOpen) drawMenu();
  else if (mode == TIMER_SCREEN) drawTimer();
  else if (mode == ART_SCREEN) drawArt();
  else if (mode == GAME_SCREEN) drawGame();
  else drawPet(now);
  display.display();
  delay(1); // Yield to the ESP32 system without blocking touch processing.
}
